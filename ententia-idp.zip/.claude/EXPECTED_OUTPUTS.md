# Expected Outputs for Each Document

This file defines the expected structured output for each document processed by the Ententia IDP multi-agent pipeline.

Each document should produce the following components:

## 1. Classification
- Document Type: a single label from the defined taxonomy.

## 2. Tags
- 3–7 semantic tags.
- Tags must be lowercase and hyphen-separated.
- Tags should be grounded in document content and reflect the main themes or attributes.

## 3. Extracted Fields
- Structured key-value data according to the schema defined in `README.md`.
- Where a field is expected but absent, return `null` rather than omitting the field.
- Provide both high-level document metadata and domain-specific values.

## 4. Summary
- A 2–3 sentence plain-language description of the document.
- Summaries should capture the key purpose, context, and any important business details.

---

# Document Output Templates

## Document 001 — Vendor Contract

### Classification
- Document Type: Vendor Contract

### Tags
- saas
- cloud-infrastructure
- auto-renewal
- liability-cap
- indemnity
- net-30
- multi-party

### Extracted Fields
- Parties: Acme Corporation; CloudBase Inc.
- Effective Date: 2024-03-01
- Expiry Date: 2025-02-28
- Contract Value: $120,000 USD/year
- Payment Terms: Quarterly in advance at $30,000/quarter; Net-30 from invoice date; 1.5% per month late interest
- Auto-Renewal: Yes — auto-renews for successive 1-year terms
- Auto-Renewal Notice Period: 45 days prior written notice to prevent renewal
- Termination Notice (Convenience): 30 days
- Termination Notice (Cause): 15 days to cure after written notice
- Governing Law: State of Delaware
- Dispute Resolution: Binding arbitration via JAMS, New York, NY
- Liability Cap: Total fees paid or payable in the 12 months immediately preceding the claim

### Summary
- A master services agreement between Acme Corporation and CloudBase Inc. for cloud hosting, managed Kubernetes orchestration, and 24/7 infrastructure monitoring, valued at $120,000/year. The 12-month contract runs from March 2024 to February 2025, auto-renews unless 45 days' notice is given, and caps liability at the prior 12 months of fees paid. Governed by Delaware law with disputes resolved via JAMS arbitration in New York.

## Document 002 — Support Ticket

### Classification
- Document Type: Support Ticket

### Tags
- p1
- production-down
- access
- data-loss-risk
- erp
- ldap
- resolved

### Extracted Fields
- Ticket ID: INC-2024-08471
- Submitted By: Priya Mehta (priya.mehta@acmecorp.com)
- Submitted Date: 2024-07-15
- Priority: Critical
- Category: Access / Data Loss
- Affected System: Oracle Financials ERP (Production)
- Assigned To: Platform Engineering Team
- Current Status: Resolved
- Description: Four Accounts Payable team members unable to log into Oracle Financials ERP since 9:00 AM IST on 2024-07-15. Error: ORA-01017 invalid username/password. Suspected cause: Oracle LDAP connector not synced after a mass AD password rotation on July 14 at 11:30 PM.
- Root Cause: Oracle LDAP connector sync job failed silently after AD password rotation
- Resolved By: Vikram Nair (vikram.nair@acmecorp.com)
- Resolution Time: 1 hour 33 minutes
- Resolution Notes: Manually re-triggered LDAP sync at 10:45 AM; sync completed at 11:10 AM. All affected users confirmed able to log in. Post-mortem scheduled for July 17.

### Summary
- A critical IT support ticket from Priya Mehta (Accounts Payable) reporting that four team members were locked out of Oracle Financials ERP on July 15, 2024, blocking ₹1.8 crore in time-sensitive vendor payments. Root cause was the LDAP connector failing to sync after a scheduled AD password rotation. Resolved by Vikram Nair in under 2 hours by manually re-triggering the LDAP sync.

## Document 003 — Statement of Work

### Classification
- Document Type: Statement of Work

### Tags
- ai
- document-processing
- ocr
- milestone-based
- fintech
- multi-party
- saas

### Extracted Fields
- Project Name: Intelligent Document Processing Automation
- SOW Number: ENT-SOW-2024-019
- Client: NovaBridge Financial Services Pvt. Ltd.
- Vendor: Ententia AI Solutions Pvt. Ltd.
- Start Date: 2024-09-20
- End Date: 2025-02-07
- Total Budget: ₹40,00,000
- Deliverables: Document Ingestion & Pre-processing Module; Document Classification Engine; Intelligent Field Extraction; Validation & Business Rules Engine; REST API integration; Admin dashboard; Testing, UAT, and training
- Milestone 1: Architecture Sign-off — ₹8,00,000 — Due 2024-09-20
- Milestone 2: Ingestion Pipeline & Classifier (Beta) — ₹10,00,000 — Due 2024-10-25
- Milestone 3: Extraction Engine & Validation Rules — ₹12,00,000 — Due 2024-12-06
- Milestone 4: API Layer, Dashboard & UAT — ₹8,00,000 — Due 2025-01-17
- Milestone 5: Go-Live, Training & Documentation — ₹2,00,000 — Due 2025-02-07
- Client Exec Sponsor: Ramesh Iyer (CTO) — ramesh.iyer@novabridge.in
- Client Project Lead: Kavitha Subramaniam — kavitha.s@novabridge.in
- Client IT Integration: Yash Malhotra — yash.malhotra@novabridge.in
- Vendor Engagement Manager: Nishant Shah — nishant.shah@ententia.ai
- Vendor Technical Lead: Arjun Pillai — arjun.pillai@ententia.ai

### Summary
- A 20-week statement of work between NovaBridge Financial Services and Ententia AI Solutions to build an AI-powered Intelligent Document Processing system for automating loan application document classification, extraction, and validation. The project runs from September 2024 to February 2025, covers 7 document classes, and is valued at ₹40,00,000 paid across 5 milestones. It includes OCR, a classification engine targeting ≥95% accuracy, field extraction with confidence scoring, validation rules, and integration with NovaBridge's Finnone loan origination system.

## Document 004 — Invoice

### Classification
- Document Type: Invoice

### Tags
- milestone-payment
- net-30
- gst
- change-order
- saas
- ai
- b2b

### Extracted Fields
- Invoice Number: ENT-INV-2024-0043
- Invoice Date: 2024-10-28
- Due Date: 2024-11-27
- Payment Terms: Net-30
- Reference SOW: ENT-SOW-2024-019
- Vendor: Ententia AI Solutions Pvt. Ltd.
- Client: NovaBridge Financial Services Pvt. Ltd.
- Line Items:
  - Milestone 2 Delivery: Document Ingestion Pipeline & Classification Model (Beta) — Qty: 1 — ₹10,00,000
  - Additional Data Annotation Services (Change Order CO-2024-003) — 40 hrs × ₹3,500 — ₹1,40,000
  - Cloud Infrastructure Setup & Configuration (one-time, at cost) — Qty: 1 — ₹60,000
- Subtotal: ₹12,00,000
- GST (18%): ₹2,16,000
- Total Amount Due: ₹14,16,000
- Payment Instructions: HDFC Bank Ltd., Noida Sector 18; Ententia AI Solutions Pvt. Ltd.; Account Number 50200098765432; IFSC HDFC0001234; billing@ententia.ai

### Summary
- An invoice from Ententia AI Solutions to NovaBridge Financial Services for ₹14,16,000 (including 18% GST), due November 27, 2024. The invoice covers Milestone 2 delivery of the document ingestion pipeline and classifier (₹10,00,000), additional annotation services under Change Order CO-2024-003 (₹1,40,000), and one-time AWS infrastructure setup (₹60,000), all under SOW ENT-SOW-2024-019.
