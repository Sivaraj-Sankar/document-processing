# Ententia IDP - Claude Project Overview

## 1. Project Overview

The Ententia Intelligent Document Processing (IDP) initiative is designed to automate the extraction, classification, validation, and integration of business documents using Claude-enabled AI workflows. The goal is to build a robust, scalable system that reduces manual effort, improves data accuracy, and accelerates document-driven business processes.

This project will leverage Claude for:
- Document understanding and intelligent extraction
- Semantic classification of document types
- Field-level data extraction with context awareness
- Business rules validation and exception handling
- API integration for downstream systems and services

## 2. What We Are Going to Develop Using Claude

We will develop a Claude-powered IDP platform with the following core capabilities:

### 2.1 Multi-Agent Processing Pipeline
- Build a multi-agent pipeline that processes unstructured documents and produces structured output for each document.
- Each document must generate:
  - a **classification**,
  - a set of **semantic tags**,
  - **extracted key fields**, and
  - a short **summary**.
- Support the sample document types referenced in `docs/expected_outputs.docx` (vendor contract, support ticket, statement of work, invoice).
- Use Claude agents specialized for ingestion, classification, extraction, tagging, and summarization.

### 2.2 Document Ingestion & Pre-processing
- Accept documents in multiple formats such as PDF, text, and images.
- Normalize incoming content and prepare it for AI-driven understanding.
- Use Claude to extract text, structure, and document metadata.

### 2.3 Document Classification Engine
- Identify document types automatically (e.g. invoices, purchase orders, contracts).
- Use semantic classification to route documents into the correct processing pipeline.
- Enable Claude to handle new or unknown document templates through natural language understanding.

### 2.4 Intelligent Field Extraction
- Extract key data fields from documents, including line items, dates, amounts, and parties.
- Apply Claude models to infer contextual relationships and capture business-critical details.
- Support both fixed template extraction and free-form document parsing.

### 2.5 Validation & Business Rules Engine
- Validate extracted data against business rules and lookup data.
- Detect anomalies, missing fields, or invalid values.
- Generate structured exceptions and correction guidance for any validation failures.

### 2.6 Integration & API Layer
- Expose processed document output through APIs for downstream consumption.
- Provide a clear payload schema for external systems.
- Enable Claude-assisted workflows for review, approval, and exception resolution.

## 3. Expected Outputs and Evaluation

This project is evaluated against the ground truth defined in `docs/expected_outputs.docx`.

The expected output for each sample document includes:
- **Classification** — the document type from the agreed taxonomy.
- **Tags** — 3–7 lowercase, hyphen-separated semantic tags grounded in the document content.
- **Extracted Fields** — structured key-value data following the schema defined in the README, with absent fields returned as null rather than omitted.
- **Summary** — a 2–3 sentence plain-language description of the document.

The four sample documents in the reference file are:
- `doc_001_vendor_contract.docx` — Vendor Contract
- `doc_002_support_ticket.pdf` — Support Ticket
- `doc_003_statement_of_work.docx` — Statement of Work
- `doc_004_invoice.pdf` — Invoice

Scoring guidance:
- Partial credit applies.
- Minor phrasing differences are acceptable.
- The focus is on semantic accuracy and complete structured output.

## 4. Key Outcomes

- Faster document processing across enterprise workflows.
- Higher extraction accuracy using Claude’s contextual understanding.
- Reduced manual validation and fewer processing exceptions.
- A foundation for future automation using Claude in document-centric applications.
